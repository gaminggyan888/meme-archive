const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Initialize database
const db = new sqlite3.Database('./database.sqlite');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS memes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    tag TEXT,
    filename TEXT
  )`);
});

// Multer config for uploads
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

// Admin upload route
app.post('/upload', upload.single('image'), (req, res) => {
  const { title, tag } = req.body;
  const filename = req.file.filename;
  db.run('INSERT INTO memes (title, tag, filename) VALUES (?, ?, ?)', [title, tag, filename], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ success: true, id: this.lastID });
  });
});

// Get memes (optional tag filter)
app.get('/memes', (req, res) => {
  const tag = req.query.tag;
  let query = 'SELECT * FROM memes';
  let params = [];
  if(tag && tag !== 'All') { query += ' WHERE tag=?'; params.push(tag); }
  db.all(query, params, (err, rows) => {
    if(err) return res.status(500).json({ error: err.message });
    rows = rows.map(r => ({...r, url: `/uploads/${r.filename}`}));
    res.json(rows);
  });
});

// Simulated payment route
app.post('/pay', (req, res) => {
  // In real deployment, integrate Razorpay / Stripe
  const { memeId } = req.body;
  res.json({ success: true, message: 'Payment successful' });
});

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
