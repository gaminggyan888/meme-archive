const API = 'http://localhost:3000';
let memes = [];
let activeTag = "All";

async function fetchMemes() {
  const res = await fetch(`${API}/memes?tag=${activeTag}`);
  memes = await res.json();
  render();
}

function render() {
  const grid = document.getElementById("grid");
  grid.innerHTML = "";
  const tags = ["All", ...new Set(memes.map(m => m.tag))];
  document.getElementById("tagBar").innerHTML = tags.map(t => `<div class="tag-btn ${t===activeTag?'active':''}" onclick="setTag('${t}')">${t}</div>`).join("");
  memes.forEach(m => {
    grid.innerHTML += `
      <div class="meme">
        <img src="${API}${m.url}">
        <div class="meme-info">
          <p>${m.title}</p>
          <span>${m.tag}</span>
          <button class="download-btn" onclick="pay('${m.id}')">Download ₹10</button>
        </div>
      </div>`;
  });
}

function setTag(tag){activeTag=tag;fetchMemes()}

async function uploadMeme(){
  const title=document.getElementById("title").value;
  const tag=document.getElementById("tag").value;
  const file=document.getElementById("image").files[0];
  if(!title||!file)return alert("Fill title and select file");
  const formData=new FormData();
  formData.append("title",title);
  formData.append("tag",tag);
  formData.append("image",file);
  await fetch(`${API}/upload`,{method:"POST",body:formData});
  fetchMemes();
}

async function pay(id){
  // Simulated payment
  await fetch(`${API}/pay`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({memeId:id})});
  const meme=memes.find(m=>m.id==id);
  const a=document.createElement("a");
  a.href=`${API}${meme.url}`;
  a.download="meme.jpg";
  a.click();
}

fetchMemes();
